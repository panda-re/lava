Toy program, preprocessed. All variables are initialized in original source code so lavaInitTool was not used.
