Preprocessed with custom Makefile
Preprocessed files initialized with lavaInitTool
Manual fixes in argmatch-pre.c to not initialize variable sized arrays
    and closeout-pre.c
