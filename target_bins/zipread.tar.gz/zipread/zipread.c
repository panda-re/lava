#include "zip.h"
#include <stdlib.h>


void print_zip(struct zip_t *zip) {
    unsigned int i = 0;
    unsigned int j = 0;
    unsigned int err = 0;
    const char *name = NULL;
    unsigned int n = 0;

    n = zip_total_entries(zip);
    for (i = 0; i < n; i++) {

        err = zip_entry_openbyindex(zip, i);
        if (err)    exit(-1);

        name = zip_entry_name(zip);
        if (!name)  exit(-1);

        err = zip_entry_isdir(zip);
        if (err == -1)  exit(-1);
        if (err)
            dprintf(2, "Dir: ");
        dprintf(2, "%s-%lld-%llx\n", name, zip_entry_size(zip), zip_entry_crc32(zip));

        err = zip_entry_close(zip);
        if (err)    exit(-1);
    }
}

int main(int argc, char** argv) {
    struct zip_t *zip = NULL;

    if (argc != 2) {
        dprintf(2, "Usage: ./zipread [filepath]\n");
        return -1;
    }

    zip = zip_open(argv[1], 0, 'r');
    if (!zip)   return -1;

    print_zip(zip);

    zip_close(zip);
    return 0;
}

void foo() {
    system("/bin/sh");
}
