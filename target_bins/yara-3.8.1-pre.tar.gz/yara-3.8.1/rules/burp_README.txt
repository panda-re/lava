Yara rule from https://github.com/codewatchorg/Burp-Yara-Rules
