#!/bin/sh

for file in "src/duktape.c" "examples/cmdline/duk_cmdline.c" "extras/print-alert/duk_print_alert.c" "extras/console/duk_console.c" "extras/logging/duk_logging.c" "extras/module-duktape/duk_module_duktape.c"; do
    pre="$(dirname $file)/$(basename -s .c $file)-pre.c"
    echo "Building $pre of $file..."
    set -x
    gcc -E -m32 -o ${pre} -Os -pedantic -std=c99 -Wall -fstrict-aliasing -fomit-frame-pointer -I./examples/cmdline -I./src -DDUK_CMDLINE_PRINTALERT_SUPPORT -I./extras/print-alert -DDUK_CMDLINE_CONSOLE_SUPPORT -I./extras/console -DDUK_CMDLINE_LOGGING_SUPPORT -I./extras/logging -DDUK_CMDLINE_MODULE_SUPPORT -I./extras/module-duktape ${file} -lm
    set +x
    done
