Manually moved all source files into newly-created src/ directory
Makefile has targets to build preprocessed versions of each
