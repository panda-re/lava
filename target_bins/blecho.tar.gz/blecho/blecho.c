
#include <errno.h>
#include <sys/types.h>
#include <dirent.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <dirent.h>
#include <assert.h>
#include <unistd.h>


// probably a bad idea
#define EXTRA_STRLEN 64

#define REM "YOUMUSTREMEMBERTHIS"
#define REC "YOUMUSTRECALLTHIS"

typedef struct string_struct {
    char *str;
    size_t len; 
} String; 

#define KEY_LEN 10
#define MIN_VAL_LEN 10
#define MAX_VAL_LEN 90
#define MAX_LINE_LEN 150
String *magic_word;
String *memory_dir;


//#define DEBUG

#ifdef DEBUG
#define blecho_printf(...) printf(__VA_ARGS__)
#else
#define blecho_printf(...) {}
#endif


void blecho_exit(int s) {
    blecho_printf("exiting with timeout\n");
    exit(1);
}

// return string that can fit len characters
String *new_string(size_t len) {
    String *s = (String *) malloc(sizeof(String));
    // len+1 to accomodate null terminator
    s->str = (char *) calloc(1,len+1);
    *((size_t *) ((char*) (&(s->len)))) = len;
    return s;
}
    

String *make_string (char *str) {
    size_t len = strlen(str);
    String *the_string = new_string(len);
    the_string->str = strdup(str);
    the_string->len = len;
    return the_string;
}


void free_string(String *str) {
    free(str->str);
    free(str);
}

    
// check that key is entirely alphanum chars
int key_ok(String *key) {
    size_t i;   
    for (i=0; i<key->len; i++) {
        if (!isalnum(key->str[i])) return 0;
    }
    return 1;
}


//  keystart points first char after REM or REC in line->str
//  key is first KEY_LEN chars that follow
String *get_key(String *line, char *keystart) {
    // make sure there's enough data there to get a key
    char *last_char = line->str + line->len;
    if (keystart + KEY_LEN > last_char) return NULL;
    String *key = new_string(KEY_LEN);
    memcpy(key->str, keystart, KEY_LEN);
    key->str[KEY_LEN] = '\0';
    blecho_printf("key is [%s]\n", key->str);
    if (!key_ok(key)) {
        blecho_printf("key is NOT ok\n");
        free_string(key);
        return NULL;
    }
    blecho_printf("key is ok\n");
    return key;
}


// generate key-value filename
String *get_keyval_filename(String *key) {
    int keyval_filename_len = memory_dir->len + 1 + KEY_LEN + EXTRA_STRLEN;
    String *keyval_filename = new_string(keyval_filename_len);
    sprintf(keyval_filename->str, "%s/%s", memory_dir->str, key->str);
    blecho_printf("keyval_filename is [%s]\n", keyval_filename->str);
    return keyval_filename;
}


void remember(String *line, char *keystart) {
    blecho_printf("Remembering ... [%s]\n", line->str);
    String *key = get_key(line, keystart);
    if (key == NULL) {
        blecho_printf("null key\n");
        return;
    }
    String *keyval_filename = get_keyval_filename(key);
    char *valstart = keystart + KEY_LEN;
    char *last_char = line->str + line->len;
    unsigned int vallen = last_char - valstart;
    if (vallen >= MIN_VAL_LEN && vallen <= MAX_VAL_LEN) {
        blecho_printf("val %d [%s]\n", vallen, valstart);
        printf ("REMEMBER key %u %s val %u %s\n",
                key->len, key->str, vallen, valstart);
        FILE *fp = fopen (keyval_filename->str, "w");
        assert (fp != NULL);
        fwrite(&vallen, sizeof(vallen), 1, fp);
        fwrite(valstart, 1, vallen, fp);
        fclose(fp);
    }
    free_string(key);
    free_string(keyval_filename);
}


void recall_key(String *key) {
    FILE *fp;
    String *keyval_filename;
    int i;
    keyval_filename = get_keyval_filename(key);
    fp = fopen (keyval_filename->str, "r");
    if (!fp) return;
    // figure out how big the val is
    unsigned int len;
    fread(&len, 1, sizeof(len), fp);
    blecho_printf ("len = %d\n", len);
    String *recall = new_string(len);
//    fread(recall->str, 1, len, fp);
    char *p = recall->str;
    for (i=0; i<len; i++) {
        char c = (char) fgetc(fp);
        *p = c;
        p++;
    }
    fclose(fp);
    recall->str[len] = '\0';
    blecho_printf("recalled: %d [%s]\n", recall->len, recall->str);
    printf("RECALL %u %s %u %s\n", key->len, key->str, recall->len, recall->str);
    free_string(recall);
    free_string(keyval_filename);
}    

void recall(String *line, char *keystart) {
    blecho_printf("Recalling ... [%s] [%s]\n", line->str, keystart);
    String *key = get_key(line, keystart);
    if (key == NULL) {
        blecho_printf("null key\n");
        return;
    }
    recall_key(key);
    free_string(key);
}


void recall_everything() {
    blecho_printf("Recalling EVERYTHING\n");
    printf ("RECALLING EVERYTHING\n");
    DIR *dir;
    struct dirent *dp;
    char *file_name;
    dir = opendir(memory_dir->str);
    while ((dp=readdir(dir)) != NULL) {
        if (dp->d_type != DT_REG) continue;
        String *key = make_string(dp->d_name);
        blecho_printf("recalling key [%s]\n", key->str);
        recall_key(key);
    }
}


void process_line(String *line) {
    blecho_printf("%d [%s]\n", line->len, line->str);
    printf("%s\n", line->str);
    char *found;
    found = strstr(line->str, REM);
    if (found) {
        // not enough key or val to remember
        if (line->len < sizeof(REM) + KEY_LEN + MIN_VAL_LEN) 
            return;
        remember(line, found + sizeof(REM));
        return;
    }
    found = strstr(line->str, REC);
    if (found) {
        // not enough key to recall
        if (line->len < sizeof(REC) + KEY_LEN) 
            return; 
        recall(line, found + sizeof(REC));
        return;
    }
    if (0 != strstr(line->str, magic_word->str)) recall_everything();
}


String *create_magic_word(int len) {
    String *magicword = new_string(len);
    int i;
    for (i=0; i<len; i++) {
        char c;
        while (1) {
            c = random() & 0xff;
            if (isalnum(c)) break;
        }
        magicword->str[i] = c;
    }
    magicword->str[len-1] = 0;
    blecho_printf("magicword=[%s]\n", magicword->str);
    return magicword;
}


void remove_directory(const char *path)
{
   DIR *d = opendir(path);
   size_t path_len = strlen(path);
   int r = -1;

   if (d) {
      struct dirent *p;
      r = 0;
      while (!r && (p=readdir(d)))  {
          int r2 = -1;
          char *buf;
          size_t len;

          /* Skip the names "." and ".." as we don't want to recurse on them. */
          if (!strcmp(p->d_name, ".") || !strcmp(p->d_name, "..")) continue;          
          len = path_len + strlen(p->d_name) + 2; 
          buf = malloc(len);
          if (buf) {
             snprintf(buf, len, "%s/%s", path, p->d_name);
             r2 = unlink(buf); 
             free(buf);
          }
      }
      closedir(d);
   }
}

int main(int argc, char **argv) {
    String *line;
    unsigned int exit_seconds, seed;
    int magic_word_len;
    int i;

    if (argc != 5) {
        printf("usage: blecho exit_seconds seed magic_word_len memory_dir\n");
        exit(1);
    }

    exit_seconds = atoi(argv[1]);
    seed = atoi(argv[2]);
    magic_word_len = atoi(argv[3]);
    memory_dir = make_string(argv[4]);
    
    blecho_printf("exit_seconds = %d\n", exit_seconds);
    blecho_printf("seed = %d\n", seed);
    blecho_printf("magic_word_len = %d\n", magic_word_len);
    blecho_printf("memory_dir = %s\n", memory_dir->str);    

    DIR *md = opendir(memory_dir->str);
    if (ENOENT != errno) {
        blecho_printf("erasing memory_dir [%s]\n", memory_dir->str);
        remove_directory(memory_dir->str);        
    }
    else {
        blecho_printf("creating memory_dir [%s]\n", memory_dir->str);
        mkdir(memory_dir->str, 0777);
    }

    // create random magic word
    magic_word = create_magic_word(magic_word_len);

    line = new_string(MAX_LINE_LEN);
    while (!feof(stdin)) {
        signal(SIGALRM, blecho_exit);
        alarm(exit_seconds);        
        ssize_t line_len = MAX_LINE_LEN;
        line->len = getline(&(line->str), &(line_len), stdin);
        if (line->len == -1) break;
        line->len--;
        line->str[line->len] = '\0';
        blecho_printf ("getline [%s]\n", line->str);
        if (line->len > 0) process_line(line);
        alarm(0);
    }
    exit(0);
}
