#!/bin/bash

# Reset blecho
#

# remove semaphore
echo Removing blecho semaphore
/bin/rm -f /dev/shm/sem.blecho_semaphore 

echo Killing all blechi
/usr/bin/killall -q blecho

echo Removing all stored keys
/bin/rm -f blecho_memory
mkdir blecho_memory

