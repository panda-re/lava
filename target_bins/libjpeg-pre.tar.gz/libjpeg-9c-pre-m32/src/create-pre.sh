#!/bin/bash

cfiles="cdjpeg cjpeg ckconfig djpeg example jaricom jcapimin jcapistd jcarith jccoefct jccolor jcdctmgr jchuff jcinit jcmainct jcmarker jcmaster jcomapi jcparam jcprepct jcsample jctrans jdapimin jdapistd jdarith jdatadst jdatasrc jdcoefct jdcolor jddctmgr jdhuff jdinput jdmainct jdmarker jdmaster jdmerge jdpostct jdsample jdtrans jerror jfdctflt jfdctfst jfdctint jidctflt jidctfst jidctint jquant1 jquant2 jutils jmemmgr jmemnobs jpegtran memdjpeg rdbmp rdcolmap rdgif rdjpgcom rdppm rdrle rdswitch rdtarga transupp wrbmp wrgif wrjpgcom wrppm wrrle wrtarga"

for cfile in $cfiles 
do
    echo $cfile
    gcc -DHAVE_CONFIG_H -m32 -I. -E   -o $cfile-pre1.c $cfile.c
    sed '/^#/d' $cfile-pre1.c > $cfile-pre.c
    rm $cfile-pre1.c
done

exit




gcc -DHAVE_CONFIG_H -I. -E      -g -O2 -MT jmemnobs.lo -MD -MP -MF .deps/jmemnobs.Tpo -c -o jmemnobs.lo jmemnobs.c
  --tag=CC   --mode=link gcc  -g -O2 -no-undefined -version-info 12:0:3 -Wl,--version-script=./libjpeg.map  -o libjpeg.la -rpath /home/tleek/software/libjpeg-9c/install/lib jaricom.lo jcapimin.lo jcapistd.lo jcarith.lo jccoefct.lo jccolor.lo jcdctmgr.lo jchuff.lo jcinit.lo jcmainct.lo jcmarker.lo jcmaster.lo jcomapi.lo jcparam.lo jcprepct.lo jcsample.lo jctrans.lo jdapimin.lo jdapistd.lo jdarith.lo jdatadst.lo jdatasrc.lo jdcoefct.lo jdcolor.lo jddctmgr.lo jdhuff.lo jdinput.lo jdmainct.lo jdmarker.lo jdmaster.lo jdmerge.lo jdpostct.lo jdsample.lo jdtrans.lo jerror.lo jfdctflt.lo jfdctfst.lo jfdctint.lo jidctflt.lo jidctfst.lo jidctint.lo jquant1.lo jquant2.lo jutils.lo jmemmgr.lo jmemnobs.lo  


gcc -DHAVE_CONFIG_H -I. -E      -g -O2 -MT cjpeg.o -MD -MP -MF .deps/cjpeg.Tpo -c -o cjpeg.o cjpeg.c
gcc -DHAVE_CONFIG_H -I. -E      -g -O2 -MT rdppm.o -MD -MP -MF .deps/rdppm.Tpo -c -o rdppm.o rdppm.c
gcc -DHAVE_CONFIG_H -I. -E      -g -O2 -MT rdgif.o -MD -MP -MF .deps/rdgif.Tpo -c -o rdgif.o rdgif.c
gcc -DHAVE_CONFIG_H -I. -E      -g -O2 -MT rdtarga.o -MD -MP -MF .deps/rdtarga.Tpo -c -o rdtarga.o rdtarga.c
gcc -DHAVE_CONFIG_H -I. -E      -g -O2 -MT rdrle.o -MD -MP -MF .deps/rdrle.Tpo -c -o rdrle.o rdrle.c
gcc -DHAVE_CONFIG_H -I. -E      -g -O2 -MT rdbmp.o -MD -MP -MF .deps/rdbmp.Tpo -c -o rdbmp.o rdbmp.c
gcc -DHAVE_CONFIG_H -I. -E      -g -O2 -MT rdswitch.o -MD -MP -MF .deps/rdswitch.Tpo -c -o rdswitch.o rdswitch.c
gcc -DHAVE_CONFIG_H -I. -E      -g -O2 -MT cdjpeg.o -MD -MP -MF .deps/cdjpeg.Tpo -c -o cdjpeg.o cdjpeg.c
  --tag=CC   --mode=link gcc  -g -O2   -o cjpeg cjpeg.o rdppm.o rdgif.o rdtarga.o rdrle.o rdbmp.o rdswitch.o cdjpeg.o libjpeg.la 
gcc -DHAVE_CONFIG_H -I. -E      -g -O2 -MT djpeg.o -MD -MP -MF .deps/djpeg.Tpo -c -o djpeg.o djpeg.c
gcc -DHAVE_CONFIG_H -I. -E      -g -O2 -MT wrppm.o -MD -MP -MF .deps/wrppm.Tpo -c -o wrppm.o wrppm.c
gcc -DHAVE_CONFIG_H -I. -E      -g -O2 -MT wrgif.o -MD -MP -MF .deps/wrgif.Tpo -c -o wrgif.o wrgif.c
gcc -DHAVE_CONFIG_H -I. -E      -g -O2 -MT wrtarga.o -MD -MP -MF .deps/wrtarga.Tpo -c -o wrtarga.o wrtarga.c
gcc -DHAVE_CONFIG_H -I. -E      -g -O2 -MT wrrle.o -MD -MP -MF .deps/wrrle.Tpo -c -o wrrle.o wrrle.c
gcc -DHAVE_CONFIG_H -I. -E      -g -O2 -MT wrbmp.o -MD -MP -MF .deps/wrbmp.Tpo -c -o wrbmp.o wrbmp.c
gcc -DHAVE_CONFIG_H -I. -E      -g -O2 -MT rdcolmap.o -MD -MP -MF .deps/rdcolmap.Tpo -c -o rdcolmap.o rdcolmap.c
  --tag=CC   --mode=link gcc  -g -O2   -o djpeg djpeg.o wrppm.o wrgif.o wrtarga.o wrrle.o wrbmp.o rdcolmap.o cdjpeg.o libjpeg.la 
gcc -DHAVE_CONFIG_H -I. -E      -g -O2 -MT jpegtran.o -MD -MP -MF .deps/jpegtran.Tpo -c -o jpegtran.o jpegtran.c
gcc -DHAVE_CONFIG_H -I. -E      -g -O2 -MT transupp.o -MD -MP -MF .deps/transupp.Tpo -c -o transupp.o transupp.c
  --tag=CC   --mode=link gcc  -g -O2   -o jpegtran jpegtran.o rdswitch.o cdjpeg.o transupp.o libjpeg.la 
gcc -DHAVE_CONFIG_H -I. -E      -g -O2 -MT rdjpgcom.o -MD -MP -MF .deps/rdjpgcom.Tpo -c -o rdjpgcom.o rdjpgcom.c
  --tag=CC   --mode=link gcc  -g -O2   -o rdjpgcom rdjpgcom.o  
gcc -DHAVE_CONFIG_H -I. -E      -g -O2 -MT wrjpgcom.o -MD -MP -MF .deps/wrjpgcom.Tpo -c -o wrjpgcom.o wrjpgcom.c
  --tag=CC   --mode=link gcc  -g -O2   -o wrjpgcom wrjpgcom.o  
gcc -DHAVE_CONFIG_H -I. -E     -g -g -O2 -MT memdjpeg-memdjpeg.o -MD -MP -MF .deps/memdjpeg-memdjpeg.Tpo -c -o memdjpeg-memdjpeg.o `test -f 'memdjpeg.c' || echo './'`memdjpeg.c
gcc -DHAVE_CONFIG_H -I. -E     -g -g -O2 -MT memdjpeg-jaricom.o -MD -MP -MF .deps/memdjpeg-jaricom.Tpo -c -o memdjpeg-jaricom.o `test -f 'jaricom.c' || echo './'`jaricom.c
gcc -DHAVE_CONFIG_H -I. -E     -g -g -O2 -MT memdjpeg-jcapimin.o -MD -MP -MF .deps/memdjpeg-jcapimin.Tpo -c -o memdjpeg-jcapimin.o `test -f 'jcapimin.c' || echo './'`jcapimin.c
gcc -DHAVE_CONFIG_H -I. -E     -g -g -O2 -MT memdjpeg-jcapistd.o -MD -MP -MF .deps/memdjpeg-jcapistd.Tpo -c -o memdjpeg-jcapistd.o `test -f 'jcapistd.c' || echo './'`jcapistd.c
gcc -DHAVE_CONFIG_H -I. -E     -g -g -O2 -MT memdjpeg-jcarith.o -MD -MP -MF .deps/memdjpeg-jcarith.Tpo -c -o memdjpeg-jcarith.o `test -f 'jcarith.c' || echo './'`jcarith.c
gcc -DHAVE_CONFIG_H -I. -E     -g -g -O2 -MT memdjpeg-jccoefct.o -MD -MP -MF .deps/memdjpeg-jccoefct.Tpo -c -o memdjpeg-jccoefct.o `test -f 'jccoefct.c' || echo './'`jccoefct.c
gcc -DHAVE_CONFIG_H -I. -E     -g -g -O2 -MT memdjpeg-jccolor.o -MD -MP -MF .deps/memdjpeg-jccolor.Tpo -c -o memdjpeg-jccolor.o `test -f 'jccolor.c' || echo './'`jccolor.c
gcc -DHAVE_CONFIG_H -I. -E     -g -g -O2 -MT memdjpeg-jcdctmgr.o -MD -MP -MF .deps/memdjpeg-jcdctmgr.Tpo -c -o memdjpeg-jcdctmgr.o `test -f 'jcdctmgr.c' || echo './'`jcdctmgr.c
gcc -DHAVE_CONFIG_H -I. -E     -g -g -O2 -MT memdjpeg-jchuff.o -MD -MP -MF .deps/memdjpeg-jchuff.Tpo -c -o memdjpeg-jchuff.o `test -f 'jchuff.c' || echo './'`jchuff.c
gcc -DHAVE_CONFIG_H -I. -E     -g -g -O2 -MT memdjpeg-jcinit.o -MD -MP -MF .deps/memdjpeg-jcinit.Tpo -c -o memdjpeg-jcinit.o `test -f 'jcinit.c' || echo './'`jcinit.c
gcc -DHAVE_CONFIG_H -I. -E     -g -g -O2 -MT memdjpeg-jcmainct.o -MD -MP -MF .deps/memdjpeg-jcmainct.Tpo -c -o memdjpeg-jcmainct.o `test -f 'jcmainct.c' || echo './'`jcmainct.c
gcc -DHAVE_CONFIG_H -I. -E     -g -g -O2 -MT memdjpeg-jcmarker.o -MD -MP -MF .deps/memdjpeg-jcmarker.Tpo -c -o memdjpeg-jcmarker.o `test -f 'jcmarker.c' || echo './'`jcmarker.c
gcc -DHAVE_CONFIG_H -I. -E     -g -g -O2 -MT memdjpeg-jcmaster.o -MD -MP -MF .deps/memdjpeg-jcmaster.Tpo -c -o memdjpeg-jcmaster.o `test -f 'jcmaster.c' || echo './'`jcmaster.c
gcc -DHAVE_CONFIG_H -I. -E     -g -g -O2 -MT memdjpeg-jcomapi.o -MD -MP -MF .deps/memdjpeg-jcomapi.Tpo -c -o memdjpeg-jcomapi.o `test -f 'jcomapi.c' || echo './'`jcomapi.c
gcc -DHAVE_CONFIG_H -I. -E     -g -g -O2 -MT memdjpeg-jcparam.o -MD -MP -MF .deps/memdjpeg-jcparam.Tpo -c -o memdjpeg-jcparam.o `test -f 'jcparam.c' || echo './'`jcparam.c
gcc -DHAVE_CONFIG_H -I. -E     -g -g -O2 -MT memdjpeg-jcprepct.o -MD -MP -MF .deps/memdjpeg-jcprepct.Tpo -c -o memdjpeg-jcprepct.o `test -f 'jcprepct.c' || echo './'`jcprepct.c
gcc -DHAVE_CONFIG_H -I. -E     -g -g -O2 -MT memdjpeg-jcsample.o -MD -MP -MF .deps/memdjpeg-jcsample.Tpo -c -o memdjpeg-jcsample.o `test -f 'jcsample.c' || echo './'`jcsample.c
gcc -DHAVE_CONFIG_H -I. -E     -g -g -O2 -MT memdjpeg-jctrans.o -MD -MP -MF .deps/memdjpeg-jctrans.Tpo -c -o memdjpeg-jctrans.o `test -f 'jctrans.c' || echo './'`jctrans.c
gcc -DHAVE_CONFIG_H -I. -E     -g -g -O2 -MT memdjpeg-jdapimin.o -MD -MP -MF .deps/memdjpeg-jdapimin.Tpo -c -o memdjpeg-jdapimin.o `test -f 'jdapimin.c' || echo './'`jdapimin.c
gcc -DHAVE_CONFIG_H -I. -E     -g -g -O2 -MT memdjpeg-jdapistd.o -MD -MP -MF .deps/memdjpeg-jdapistd.Tpo -c -o memdjpeg-jdapistd.o `test -f 'jdapistd.c' || echo './'`jdapistd.c
gcc -DHAVE_CONFIG_H -I. -E     -g -g -O2 -MT memdjpeg-jdarith.o -MD -MP -MF .deps/memdjpeg-jdarith.Tpo -c -o memdjpeg-jdarith.o `test -f 'jdarith.c' || echo './'`jdarith.c
gcc -DHAVE_CONFIG_H -I. -E     -g -g -O2 -MT memdjpeg-jdatadst.o -MD -MP -MF .deps/memdjpeg-jdatadst.Tpo -c -o memdjpeg-jdatadst.o `test -f 'jdatadst.c' || echo './'`jdatadst.c
gcc -DHAVE_CONFIG_H -I. -E     -g -g -O2 -MT memdjpeg-jdatasrc.o -MD -MP -MF .deps/memdjpeg-jdatasrc.Tpo -c -o memdjpeg-jdatasrc.o `test -f 'jdatasrc.c' || echo './'`jdatasrc.c
gcc -DHAVE_CONFIG_H -I. -E     -g -g -O2 -MT memdjpeg-jdcoefct.o -MD -MP -MF .deps/memdjpeg-jdcoefct.Tpo -c -o memdjpeg-jdcoefct.o `test -f 'jdcoefct.c' || echo './'`jdcoefct.c
gcc -DHAVE_CONFIG_H -I. -E     -g -g -O2 -MT memdjpeg-jdcolor.o -MD -MP -MF .deps/memdjpeg-jdcolor.Tpo -c -o memdjpeg-jdcolor.o `test -f 'jdcolor.c' || echo './'`jdcolor.c
gcc -DHAVE_CONFIG_H -I. -E     -g -g -O2 -MT memdjpeg-jddctmgr.o -MD -MP -MF .deps/memdjpeg-jddctmgr.Tpo -c -o memdjpeg-jddctmgr.o `test -f 'jddctmgr.c' || echo './'`jddctmgr.c
gcc -DHAVE_CONFIG_H -I. -E     -g -g -O2 -MT memdjpeg-jdhuff.o -MD -MP -MF .deps/memdjpeg-jdhuff.Tpo -c -o memdjpeg-jdhuff.o `test -f 'jdhuff.c' || echo './'`jdhuff.c
gcc -DHAVE_CONFIG_H -I. -E     -g -g -O2 -MT memdjpeg-jdinput.o -MD -MP -MF .deps/memdjpeg-jdinput.Tpo -c -o memdjpeg-jdinput.o `test -f 'jdinput.c' || echo './'`jdinput.c
gcc -DHAVE_CONFIG_H -I. -E     -g -g -O2 -MT memdjpeg-jdmainct.o -MD -MP -MF .deps/memdjpeg-jdmainct.Tpo -c -o memdjpeg-jdmainct.o `test -f 'jdmainct.c' || echo './'`jdmainct.c
gcc -DHAVE_CONFIG_H -I. -E     -g -g -O2 -MT memdjpeg-jdmarker.o -MD -MP -MF .deps/memdjpeg-jdmarker.Tpo -c -o memdjpeg-jdmarker.o `test -f 'jdmarker.c' || echo './'`jdmarker.c
gcc -DHAVE_CONFIG_H -I. -E     -g -g -O2 -MT memdjpeg-jdmaster.o -MD -MP -MF .deps/memdjpeg-jdmaster.Tpo -c -o memdjpeg-jdmaster.o `test -f 'jdmaster.c' || echo './'`jdmaster.c
gcc -DHAVE_CONFIG_H -I. -E     -g -g -O2 -MT memdjpeg-jdmerge.o -MD -MP -MF .deps/memdjpeg-jdmerge.Tpo -c -o memdjpeg-jdmerge.o `test -f 'jdmerge.c' || echo './'`jdmerge.c
gcc -DHAVE_CONFIG_H -I. -E     -g -g -O2 -MT memdjpeg-jdpostct.o -MD -MP -MF .deps/memdjpeg-jdpostct.Tpo -c -o memdjpeg-jdpostct.o `test -f 'jdpostct.c' || echo './'`jdpostct.c
gcc -DHAVE_CONFIG_H -I. -E     -g -g -O2 -MT memdjpeg-jdsample.o -MD -MP -MF .deps/memdjpeg-jdsample.Tpo -c -o memdjpeg-jdsample.o `test -f 'jdsample.c' || echo './'`jdsample.c
gcc -DHAVE_CONFIG_H -I. -E     -g -g -O2 -MT memdjpeg-jdtrans.o -MD -MP -MF .deps/memdjpeg-jdtrans.Tpo -c -o memdjpeg-jdtrans.o `test -f 'jdtrans.c' || echo './'`jdtrans.c
gcc -DHAVE_CONFIG_H -I. -E     -g -g -O2 -MT memdjpeg-jerror.o -MD -MP -MF .deps/memdjpeg-jerror.Tpo -c -o memdjpeg-jerror.o `test -f 'jerror.c' || echo './'`jerror.c
gcc -DHAVE_CONFIG_H -I. -E     -g -g -O2 -MT memdjpeg-jfdctflt.o -MD -MP -MF .deps/memdjpeg-jfdctflt.Tpo -c -o memdjpeg-jfdctflt.o `test -f 'jfdctflt.c' || echo './'`jfdctflt.c
gcc -DHAVE_CONFIG_H -I. -E     -g -g -O2 -MT memdjpeg-jfdctfst.o -MD -MP -MF .deps/memdjpeg-jfdctfst.Tpo -c -o memdjpeg-jfdctfst.o `test -f 'jfdctfst.c' || echo './'`jfdctfst.c
gcc -DHAVE_CONFIG_H -I. -E     -g -g -O2 -MT memdjpeg-jfdctint.o -MD -MP -MF .deps/memdjpeg-jfdctint.Tpo -c -o memdjpeg-jfdctint.o `test -f 'jfdctint.c' || echo './'`jfdctint.c
gcc -DHAVE_CONFIG_H -I. -E     -g -g -O2 -MT memdjpeg-jidctflt.o -MD -MP -MF .deps/memdjpeg-jidctflt.Tpo -c -o memdjpeg-jidctflt.o `test -f 'jidctflt.c' || echo './'`jidctflt.c
gcc -DHAVE_CONFIG_H -I. -E     -g -g -O2 -MT memdjpeg-jidctfst.o -MD -MP -MF .deps/memdjpeg-jidctfst.Tpo -c -o memdjpeg-jidctfst.o `test -f 'jidctfst.c' || echo './'`jidctfst.c
gcc -DHAVE_CONFIG_H -I. -E     -g -g -O2 -MT memdjpeg-jidctint.o -MD -MP -MF .deps/memdjpeg-jidctint.Tpo -c -o memdjpeg-jidctint.o `test -f 'jidctint.c' || echo './'`jidctint.c
gcc -DHAVE_CONFIG_H -I. -E     -g -g -O2 -MT memdjpeg-jquant1.o -MD -MP -MF .deps/memdjpeg-jquant1.Tpo -c -o memdjpeg-jquant1.o `test -f 'jquant1.c' || echo './'`jquant1.c
gcc -DHAVE_CONFIG_H -I. -E     -g -g -O2 -MT memdjpeg-jquant2.o -MD -MP -MF .deps/memdjpeg-jquant2.Tpo -c -o memdjpeg-jquant2.o `test -f 'jquant2.c' || echo './'`jquant2.c
gcc -DHAVE_CONFIG_H -I. -E     -g -g -O2 -MT memdjpeg-jutils.o -MD -MP -MF .deps/memdjpeg-jutils.Tpo -c -o memdjpeg-jutils.o `test -f 'jutils.c' || echo './'`jutils.c
gcc -DHAVE_CONFIG_H -I. -E     -g -g -O2 -MT memdjpeg-jmemmgr.o -MD -MP -MF .deps/memdjpeg-jmemmgr.Tpo -c -o memdjpeg-jmemmgr.o `test -f 'jmemmgr.c' || echo './'`jmemmgr.c
gcc -DHAVE_CONFIG_H -I. -E     -g -g -O2 -MT memdjpeg-jmemnobs.o -MD -MP -MF .deps/memdjpeg-jmemnobs.Tpo -c -o memdjpeg-jmemnobs.o `test -f 'jmemnobs.c' || echo './'`jmemnobs.c
  --tag=CC   --mode=link gcc -g -g -O2   -o memdjpeg memdjpeg-memdjpeg.o memdjpeg-jaricom.o memdjpeg-jcapimin.o memdjpeg-jcapistd.o memdjpeg-jcarith.o memdjpeg-jccoefct.o memdjpeg-jccolor.o memdjpeg-jcdctmgr.o memdjpeg-jchuff.o memdjpeg-jcinit.o memdjpeg-jcmainct.o memdjpeg-jcmarker.o memdjpeg-jcmaster.o memdjpeg-jcomapi.o memdjpeg-jcparam.o memdjpeg-jcprepct.o memdjpeg-jcsample.o memdjpeg-jctrans.o memdjpeg-jdapimin.o memdjpeg-jdapistd.o memdjpeg-jdarith.o memdjpeg-jdatadst.o memdjpeg-jdatasrc.o memdjpeg-jdcoefct.o memdjpeg-jdcolor.o memdjpeg-jddctmgr.o memdjpeg-jdhuff.o memdjpeg-jdinput.o memdjpeg-jdmainct.o memdjpeg-jdmarker.o memdjpeg-jdmaster.o memdjpeg-jdmerge.o memdjpeg-jdpostct.o memdjpeg-jdsample.o memdjpeg-jdtrans.o memdjpeg-jerror.o memdjpeg-jfdctflt.o memdjpeg-jfdctfst.o memdjpeg-jfdctint.o memdjpeg-jidctflt.o memdjpeg-jidctfst.o memdjpeg-jidctint.o memdjpeg-jquant1.o memdjpeg-jquant2.o memdjpeg-jutils.o memdjpeg-jmemmgr.o memdjpeg-jmemnobs.o  
