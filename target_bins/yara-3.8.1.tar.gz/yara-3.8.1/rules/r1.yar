rule R1
{
   strings:
    $a = "string"
    $b = "input"

     condition:
      $a or $b
}
