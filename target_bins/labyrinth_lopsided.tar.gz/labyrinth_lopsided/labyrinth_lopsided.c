#include <stdio.h>

/*
 * A deliberately lopsided execution tree, for telling KLEE's random-path selection apart
 * from uniform random state selection (on a balanced tree like labyrinth they look alike).
 * Byte 0 >= 128: a long loop that never forks, then print "S". One path (the shallow side).
 * Byte 0 <  128: eight more independent byte tests, printing L/R. 256 paths (the deep side).
 * Random-path gives each side of the first fork half of all selections, so the long shallow
 * path still finishes early. Uniform random state selection gives it 1/(number of live
 * states), so once the deep side has forked it starves, and finishes near the very end.
 * The loop is what makes the difference visible: it keeps the shallow side alive while the
 * deep side forks.
 */
#define SHALLOW_WORK 200
int main(int argc, char **argv) {
    unsigned char path[9];
    if (argc != 2) {
        fprintf(stderr, "usage: %s <file>\n", argv[0]);
        return 1;
    }
    FILE *f = fopen(argv[1], "rb");
    if (!f) {
        fprintf(stderr, "failed to open file %s\n", argv[1]);
        return 1;
    }
    size_t bytes_read = fread(path, 1, sizeof(path), f);
    fclose(f);
    if (bytes_read < sizeof(path)) {
        fprintf(stderr, "failed to read %zu bytes from the file %s\n", sizeof(path), argv[1]);
        return 1;
    }

    if (path[0] >= 128) {
        volatile unsigned int work = 0;
        for (unsigned int i = 0; i < SHALLOW_WORK; i++) {
            work += i;
        }
        printf("S %u\n", work);
        return 0;
    }
    for (int i = 1; i < 9; i++) {
        if (path[i] < 128) {
            printf("L");
        } else {
            printf("R");
        }
    }
    printf("\nDone.\n");
    return 0;
}
