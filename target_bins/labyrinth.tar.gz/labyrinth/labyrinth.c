#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

/* * This program is a pure test of Search Strategies.
 * It creates a perfectly balanced binary tree of depth 8.
 * Total paths: 256.
 */
int main(int argc, char **argv) {
    unsigned char path[8];
    if (argc != 2) {
        fprintf(stderr, "usage: %s <file>\n", argv[0]);
        return 1;
    }
    FILE *f = fopen(argv[1], "rb");
    if (!f) {
        fprintf(stderr, "failed to open file %s\n", argv[1]);
        return 1;
    }

    int bytes_read = fread(path, 1, sizeof(path), f);
    if (bytes_read < sizeof(path)) {
        fprintf(stderr, "failed to read %ld bytes from the file %s\n", sizeof(path), argv[1]);
        return 1;
    }

    int depth = 0;
    for (int i = 0; i < 8; i++) {
        // Every bit creates a new branch
        if (path[i] < 128) {
            printf("L"); // Left Branch
        } else {
            printf("R"); // Right Branch
        }
    }
    printf("\nDone.\n");
    if (f) {
        fclose(f);
    }
    return 0;
}