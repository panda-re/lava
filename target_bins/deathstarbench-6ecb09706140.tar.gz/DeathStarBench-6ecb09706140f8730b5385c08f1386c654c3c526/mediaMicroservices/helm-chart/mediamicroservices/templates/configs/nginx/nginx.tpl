{{- define "mediamicroservices.templates.nginx.nginx.conf"  }}
# Load the OpenTracing dynamic module.
load_module modules/ngx_http_opentracing_module.so;

# Checklist: Make sure that worker_processes == #cores you gave to
# nginx process
worker_processes  auto;

error_log  logs/error.log;

# Checklist: Make sure that worker_connections * worker_processes
# is greater than the total connections between the client and Nginx.
events {
  use epoll;
  worker_connections  1024;
}

env fqdn_suffix;

http {
  # Load a vendor tracer
  opentracing on;
  opentracing_load_tracer /usr/local/lib/libjaegertracing_plugin.so /usr/local/openresty/nginx/jaeger-config.json;

  include       mime.types;
  default_type  application/octet-stream;

  log_format main '$remote_addr - $remote_user [$time_local] "$request"'
                  '$status $body_bytes_sent "$http_referer" '
                  '"$http_user_agent" "$http_x_forwarded_for"';
  # access_log  logs/access.log  main;

  sendfile        on;
  tcp_nopush      on;
  tcp_nodelay     on;

  # Checklist: Make sure the keepalive_timeout is greateer than
  # the duration of your experiment and keepalive_requests
  # is greateer than the total number of requests sent from
  # the workload generator
  keepalive_timeout  120s;
  keepalive_requests 100000;

  # Docker default hostname resolver
  # resolver 127.0.0.11 ipv6=off;

  # Kubernetes default hostname resolver
  resolver {{ .Values.global.nginx.resolverName }} ipv6=off;

  lua_package_path '/usr/local/openresty/nginx/lua-scripts/?.lua;;';

  server {

    # Checklist: Set up the port that nginx listens to.
    listen       8080 reuseport;
    server_name  localhost;

    # Checklist: Turn of the access_log and error_log if you
    # don't need them.
    access_log  off;
    # error_log off;

    lua_need_request_body on;

    # Checklist: Make sure that the location here is consistent
    # with the location you specified in wrk2.
    location /wrk2-api/user/register {
      content_by_lua '
          local client = require "wrk2-api/user/register"
          client.RegisterUser();
      ';
    }

    location /wrk2-api/movie/register {
      content_by_lua '
          local client = require "wrk2-api/movie/register"
          client.RegisterMovie();
      ';
    }

    location /wrk2-api/review/compose {
      content_by_lua '
          local client = require "wrk2-api/review/compose"
          client.ComposeReview();
      ';
    }

    location /wrk2-api/movie-info/write {
      content_by_lua '
          local client = require "wrk2-api/movie-info/write"
          client.WriteMovieInfo();
      ';
    }

    location /wrk2-api/cast-info/write {
      content_by_lua '
          local client = require "wrk2-api/cast-info/write"
          client.WriteCastInfo();
      ';
    }

    location /wrk2-api/plot/write {
      content_by_lua '
          local client = require "wrk2-api/plot/write"
          client.WritePlot();
      ';
    }
  }
}
{{- end}}
